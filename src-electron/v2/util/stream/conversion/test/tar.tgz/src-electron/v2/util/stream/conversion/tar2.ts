import * as stream from 'stream';
import * as tar from 'tar-stream';
import { sleep } from 'src/scripts/sleep';
import { Bytes } from '../bytes';
import { MemDir } from '../memdir';
import { Path } from '../path';
import {
  Conversion,
  EntryData,
  Readable,
  StreamKind,
  Writable,
} from '../stream';

class TarExtract extends stream.Transform {
  private extract: tar.Extract;

  constructor() {
    super({ readableObjectMode: true });
    this.extract = tar.extract();

    this.extract.on('entry', (header, stream, next) => {
      const dat: EntryData = { header, stream, next };
      this.push(dat);
    });
  }

  _transform(
    chunk: Buffer,
    encoding: string,
    callback: (error?: Error | null) => void
  ): void {
    if (!this.extract.write(chunk)) {
      this.extract.once('drain', () => {
        callback();
      });
    } else {
      callback();
    }
  }
}

export const fromTar = () =>
  new Conversion<StreamKind.BIN, StreamKind.ENTRY>(new TarExtract());

class TarPack extends stream.Transform {
  private pack: tar.Pack;
  private finalcb = () => {};

  constructor() {
    super({ writableObjectMode: true });
    this.pack = tar.pack();

    this.pack.on('data', (chunk) => {
      this.push(chunk);
    });

    this.pack.on('end', () => {
      this.finalcb();
    });
  }

  _transform(
    chunk: EntryData,
    encoding: string,
    callback: (error?: Error | null) => void
  ): void {
    console.log('_transform', chunk.header.name);
    chunk.stream.pipe(
      this.pack.entry(chunk.header, () => {
        chunk.next();
        this.resume();
        callback();
      })
    );
    this.pause();
  }

  async _final(callback: (error?: Error | null | undefined) => void): void {
    this.pack.finalize();
    this.finalcb = callback;
  }
}

export const toTar = () =>
  new Conversion<StreamKind.ENTRY, StreamKind.BIN>(new TarPack());

/** In Source Testing */
if (import.meta.vitest) {
  const { test, expect } = import.meta.vitest;
  test(
    '',
    async () => {
      const src = new Path('node_mo.tgz');
      const tgt = new Path('node_mo2.tgz');
      await tgt.remove();

      const tarfile = src.file.createReadStream();

      // console.log((await tarfile.into(Bytes)).value().data);

      const memdir = (await tarfile.convert(fromTar()).into(MemDir)).value();

      console.log(memdir.data.map((x) => x.header.name));

      console.log(await memdir.convert(toTar()).into(tgt.file));
    },
    {
      timeout: 100000,
    }
  );
}
