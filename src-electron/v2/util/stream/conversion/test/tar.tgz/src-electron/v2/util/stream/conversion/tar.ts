import * as stream from 'stream';
import * as tar from 'tar-stream';
import { MemDir } from '../memdir';
import { Path } from '../path';
import { Conversion, StreamKind } from '../stream';

class TarExtract extends stream.Transform {
  private extract: tar.Extract;

  constructor() {
    super({ readableObjectMode: true });
    this.extract = tar.extract();

    this.extract.on('entry', (header, stream, next) => {
      const chunks: Buffer[] = [];

      stream.on('data', (chunk: Buffer) => {
        chunks.push(chunk);
      });

      stream.on('end', () => {
        // エントリの内容を結合してオブジェクトとしてpush
        this.push({
          header,
          content: Buffer.concat(chunks),
        });
        next();
      });
      stream.resume(); // ストリームを消費する
    });
  }

  // Writableの_writeメソッドを実装
  _transform(
    chunk: any,
    encoding: string,
    callback: (error?: Error | null) => void
  ): void {
    if (!this.extract.write(chunk)) {
      this.extract.once('drain', () => {
        callback();
      });
    } else {
      callback();
    }
  }
}

export const fromTar = () =>
  new Conversion<StreamKind.BIN, StreamKind.ENTRY>(new TarExtract());

class TarPack extends stream.Transform {
  private pack: tar.Pack;

  constructor() {
    super({ writableObjectMode: true });
    this.pack = tar.pack();

    this.pack.on('data', (chunk) => {
      const chunks: Buffer[] = [];

      stream.on('data', (chunk: Buffer) => {
        chunks.push(chunk);
      });

      stream.on('end', () => {
        // エントリの内容を結合してオブジェクトとしてpush
        this.push({
          header,
          content: Buffer.concat(chunks),
        });
        next();
      });
      stream.resume(); // ストリームを消費する
    });
  }
}

/** In Source Testing */
if (import.meta.vitest) {
  const { test, expect } = import.meta.vitest;
  test('', async () => {
    const tarfile = new Path('test.tgz').file.createReadStream();
    const c = await tarfile.convert(fromTar()).into(MemDir);
    console.log(c.value().data.map((x) => x.header.name));
  });
}
